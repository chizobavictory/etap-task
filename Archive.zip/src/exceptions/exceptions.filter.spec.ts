import { ExceptionsFilter } from './exceptions.filter';

describe('ExceptionsFilter', () => {
  it('should be defined', () => {
    expect(new ExceptionsFilter()).toBeDefined();
  });
});
